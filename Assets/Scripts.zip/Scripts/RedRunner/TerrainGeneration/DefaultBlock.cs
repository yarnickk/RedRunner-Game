﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace RedRunner.TerrainGeneration
{

	public class DefaultBlock : Block
	{

	}

}