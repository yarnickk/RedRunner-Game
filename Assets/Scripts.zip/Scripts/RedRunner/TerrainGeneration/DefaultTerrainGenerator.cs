﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using RedRunner.Characters;

namespace RedRunner.TerrainGeneration
{

	public class DefaultTerrainGenerator : TerrainGenerator
	{

	}

}